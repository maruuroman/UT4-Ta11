import { useState, useEffect } from 'react';
import reactLogo from './assets/react.svg';

import './App.css';

function App() {
  // Estado para almacenar los segundos del temporizador
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    // Iniciamos el temporizador que incrementa cada segundo
    const intervalId = setInterval(() => {
      setSeconds((prevSeconds) => prevSeconds + 1); // Incrementa el temporizador
    }, 1000);

    // Limpiamos el intervalo cuando el componente se desmonta
    return () => {
      clearInterval(intervalId);
    };
  }, []); // El array vacío asegura que el temporizador solo se inicie una vez

  return (
    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src="/vite.svg" className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        <p>Temporizador: {seconds} segundos</p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  );
}

export default App;
